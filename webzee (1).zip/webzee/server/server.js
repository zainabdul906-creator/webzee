require("dotenv").config();
const express = require("express");
const cors = require("cors");
const db = require("./db");

const companiesRouter = require("./routes/companies");
const compareRouter = require("./routes/compare");
const dashboardRouter = require("./routes/dashboard");

const app = express();
const PORT = process.env.PORT || 5050;

// Set CORS_ORIGIN to your deployed frontend's URL in production
// (e.g. https://webzee.vercel.app). Left unset, allows any origin — fine
// for local dev, not for production.
const corsOrigin = process.env.CORS_ORIGIN;
app.use(cors(corsOrigin ? { origin: corsOrigin } : {}));
app.use(express.json());

app.use("/api/companies", companiesRouter);
app.use("/api/compare", compareRouter);
app.use("/api/dashboard", dashboardRouter);

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", db: db.isUsingMongo() ? "mongodb" : "in-memory" });
});

db.connect().then(() => {
  app.listen(PORT, () => {
    console.log(`Webzee API running on http://localhost:${PORT}`);
  });
});
