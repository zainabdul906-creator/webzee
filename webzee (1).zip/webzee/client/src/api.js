// In dev, Vite proxies /api to localhost:5050 (see vite.config.js).
// In production, set VITE_API_URL to your deployed backend's URL,
// e.g. https://webzee-api.onrender.com
const BASE = import.meta.env.VITE_API_URL ? `${import.meta.env.VITE_API_URL}/api` : "/api";

async function get(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) throw new Error(`Request failed: ${path}`);
  return res.json();
}

export const api = {
  companies: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return get(`/companies${qs ? `?${qs}` : ""}`);
  },
  company: (slug) => get(`/companies/${slug}`),
  compare: (slugs) => get(`/compare?slugs=${slugs.join(",")}`),
  dashboard: () => get(`/dashboard`)
};
